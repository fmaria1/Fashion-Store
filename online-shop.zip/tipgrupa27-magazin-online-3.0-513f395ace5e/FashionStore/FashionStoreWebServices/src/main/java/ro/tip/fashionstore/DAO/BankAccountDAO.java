package ro.tip.fashionstore.DAO;

import java.util.List;

import ro.tip.fashionstore.model.BankAccount;

public interface BankAccountDAO {
	BankAccount createBankAccount(BankAccount bankAccount);

	BankAccount findBankAccount(long id);

	BankAccount updateBankAccount(long id, BankAccount bankAccount);

	List<BankAccount> findAll();

	void deleteBankAccount(long id);
}
