package ro.tip.fashionstore.service.REST;

import java.util.Date;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import ro.tip.fashionstore.DAO.BankAccountDAO;
import ro.tip.fashionstore.model.BankAccount;

@Path("/api/bank-accounts")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BankAccountRestService {
	
	private BankAccountDAO bankAccountDAO;

	@SuppressWarnings("deprecation")
	@GET
	@Path("/dummy")
	public BankAccount getDummyBankAccount() {
		BankAccount u = new BankAccount();
		u.setCardNumber("1111 2222 3333 4444");
		u.setCvvCode(123);
		u.setId(1l);
		Date expDate = new Date(2023,02,16);
		u.setExpirationDate(expDate);
		
		return u;
	}

	@POST
	@Path("/add")
	public Response save(BankAccount bankAccount) {
		return Response.ok(bankAccountDAO.createBankAccount(bankAccount)).build();
	}

	@GET
	@Path("/{id}")
	public Response get(@PathParam("id") Long id) {
		BankAccount bankAccount = bankAccountDAO.findBankAccount(id);
		if (bankAccount != null)
			return Response.status(Response.Status.OK).entity(bankAccount).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@PUT
	@Path("/{id}")
	public BankAccount update(BankAccount bankAccount, @PathParam("id") Long id) {
		if (id == bankAccount.getId())
			return bankAccountDAO.updateBankAccount(id, bankAccount);
		return null;
	}

	@DELETE
	@Path("/{id}")
	public void deleteUser(@PathParam("id") Long id) {
		bankAccountDAO.deleteBankAccount(id);
	}

	@Inject
	public void setBankAccountDAO(BankAccountDAO bankAccountDAO) {
		this.bankAccountDAO = bankAccountDAO;
	}

}
