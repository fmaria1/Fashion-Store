package ro.tip.fashionstore.DAO;

import java.util.List;

import ro.tip.fashionstore.model.User;

public interface UserDAO {
	User createUser(User user);

	User findUser(long id);

	User checkUserCredentials(User user);

	User updateUser(long id, User user);

	List<User> findAll();

	void deleteUser(long id);
}