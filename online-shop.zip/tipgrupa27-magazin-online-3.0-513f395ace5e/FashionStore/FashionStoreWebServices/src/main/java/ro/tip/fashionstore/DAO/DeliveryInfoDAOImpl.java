package ro.tip.fashionstore.DAO;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import ro.tip.fashionstore.model.DeliveryInfo;

public class DeliveryInfoDAOImpl implements DeliveryInfoDAO {

	@Inject
	private EntityManager entityManager;

	private boolean isPhoneNumberValid(String phoneNumber) {
		if (phoneNumber.matches("[0-9]+") && phoneNumber.length() == 10)
			return true;
		return false;
	}

	@Override
	public DeliveryInfo createDeliveryInfo(DeliveryInfo deliveryInfo) {
		if (isPhoneNumberValid(deliveryInfo.getPhoneNumber())) {
			entityManager.getTransaction().begin();
			deliveryInfo = entityManager.merge(deliveryInfo);
			entityManager.getTransaction().commit();
			return deliveryInfo;
		}
		return null;
	}

	@Override
	public DeliveryInfo findDeliveryInfo(long id) {
		return entityManager.find(DeliveryInfo.class, id);
	}

	@Override
	public DeliveryInfo updateDeliveryInfo(long id, DeliveryInfo deliveryInfo) {
		DeliveryInfo oldDeliveryInfo = entityManager.find(DeliveryInfo.class, id);
		if (oldDeliveryInfo != null) {
			deliveryInfo.setId(id);
			entityManager.getTransaction().begin();
			oldDeliveryInfo = entityManager.merge(deliveryInfo);
			entityManager.getTransaction().commit();
			return oldDeliveryInfo;
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<DeliveryInfo> findAll() {
		return entityManager.createQuery("SELECT di FROM DeliveryInfo di").getResultList();
	}

	@Override
	public void deleteDeliveryInfo(long id) {
		DeliveryInfo deliveryInfo = entityManager.find(DeliveryInfo.class, id);
		entityManager.getTransaction().begin();
		entityManager.remove(deliveryInfo);
		entityManager.getTransaction().commit();
	}

}