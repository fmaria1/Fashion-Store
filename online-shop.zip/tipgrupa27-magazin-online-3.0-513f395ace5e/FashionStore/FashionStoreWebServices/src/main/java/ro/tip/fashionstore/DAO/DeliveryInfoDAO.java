package ro.tip.fashionstore.DAO;

import java.util.List;

import ro.tip.fashionstore.model.DeliveryInfo;

public interface DeliveryInfoDAO {
	DeliveryInfo createDeliveryInfo(DeliveryInfo deliveryInfo);

	DeliveryInfo findDeliveryInfo(long id);

	DeliveryInfo updateDeliveryInfo(long id, DeliveryInfo deliveryInfo);

	List<DeliveryInfo> findAll();

	void deleteDeliveryInfo(long id);
}
