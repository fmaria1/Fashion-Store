package ro.tip.fashionstore.configuration;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import ro.tip.fashionstore.service.REST.BankAccountRestService;
import ro.tip.fashionstore.service.REST.DeliveryInfoRestService;
import ro.tip.fashionstore.service.REST.OrdersRestService;
import ro.tip.fashionstore.service.REST.ProductRestService;
import ro.tip.fashionstore.service.REST.RequestRestService;
import ro.tip.fashionstore.service.REST.UserRestService;

public class ConfigureRestServices extends Application {

	private Set<Class<?>> classes = new HashSet<>();

	public ConfigureRestServices() {
		classes.add(UserRestService.class);
		classes.add(OrdersRestService.class);
		classes.add(DeliveryInfoRestService.class);
		classes.add(BankAccountRestService.class);
		classes.add(RequestRestService.class);
		classes.add(ProductRestService.class);
		
	}

	@Override
	public Set<Class<?>> getClasses() {
		return classes;
	}

}