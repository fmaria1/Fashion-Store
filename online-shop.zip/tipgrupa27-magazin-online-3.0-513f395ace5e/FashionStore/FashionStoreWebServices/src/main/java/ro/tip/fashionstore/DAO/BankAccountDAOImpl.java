package ro.tip.fashionstore.DAO;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import ro.tip.fashionstore.model.BankAccount;

public class BankAccountDAOImpl implements BankAccountDAO {

	@Inject
	private EntityManager entityManager;

	private boolean isBankAccountValid(BankAccount bankAccount) {
		if (!bankAccount.getCardNumber().matches("[0-9]+") || bankAccount.getCardNumber().length() != 16)
			return false;
		if (bankAccount.getCvvCode() < 100 || bankAccount.getCvvCode() > 999)
			return false;
		Long dateDifference = (bankAccount.getExpirationDate().getTime() - (new java.util.Date()).getTime());
		if (dateDifference <= 0)
			return false;
		return true;
	}

	@Override
	public BankAccount createBankAccount(BankAccount bankAccount) {
		if (isBankAccountValid(bankAccount)) {
			entityManager.getTransaction().begin();
			bankAccount = entityManager.merge(bankAccount);
			entityManager.getTransaction().commit();
			return bankAccount;
		}
		return null;
	}

	@Override
	public BankAccount findBankAccount(long id) {
		return entityManager.find(BankAccount.class, id);
	}

	@Override
	public BankAccount updateBankAccount(long id, BankAccount bankAccount) {
		BankAccount oldBankAccount = entityManager.find(BankAccount.class, id);
		if (oldBankAccount != null) {
			bankAccount.setId(id);
			entityManager.getTransaction().begin();
			oldBankAccount = entityManager.merge(bankAccount);
			entityManager.getTransaction().commit();
			return oldBankAccount;
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<BankAccount> findAll() {
		return entityManager.createQuery("SELECT ba FROM BankAccount ba").getResultList();
	}

	@Override
	public void deleteBankAccount(long id) {
		BankAccount bankAccount = entityManager.find(BankAccount.class, id);
		entityManager.getTransaction().begin();
		entityManager.remove(bankAccount);
		entityManager.getTransaction().commit();
	}

}