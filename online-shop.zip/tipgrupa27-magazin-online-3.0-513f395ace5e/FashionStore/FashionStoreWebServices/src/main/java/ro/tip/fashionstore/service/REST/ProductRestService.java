package ro.tip.fashionstore.service.REST;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import ro.tip.fashionstore.DAO.ProductDAO;
import ro.tip.fashionstore.model.Product;

@Path("/api/products")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ProductRestService {

	private ProductDAO productDAO;

	@GET
	@Path("/dummy")
	public Product getDummyProduct() {
		Product u = new Product();
		u.setName("Tricou");
		u.setDescription("Dama");
		u.setId(1l);
		u.setPrice(100);
		u.setSize("M");
		u.setStock(10);
		u.setType('F');

		return u;
	}

	@POST
	@Path("/add")
	public Response save(Product product) {
		return Response.ok(productDAO.createProduct(product)).build();
	}

	@GET
	@Path("/{id}")
	public Response get(@PathParam("id") Long id) {
		Product product = productDAO.findProduct(id);
		if (product != null)
			return Response.status(Response.Status.OK).entity(product).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@GET
	public Response getAll() {
		List<Product> productList = productDAO.findAll();
		if (productList != null)
			return Response.status(Response.Status.OK).entity(productList).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@GET
	@Path("/men")
	public Response getAllProductsForMen() {
		List<Product> productList = productDAO.findAllProductsForMen();
		if (productList != null)
			return Response.status(Response.Status.OK).entity(productList).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@GET
	@Path("/women")
	public Response getAllProductsForWomen() {
		List<Product> productList = productDAO.findAllProductsForWomen();
		if (productList != null)
			return Response.status(Response.Status.OK).entity(productList).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	/**
	 * we can't use @GET because the productName contains spaces
	 * 
	 * @return a response which contains a list of colours (Strings)
	 */
	@POST
	@Path("/available-colours")
	public Response getAllAvailableColours(String productName) {
		List<String> availableColours = productDAO.findAllAvailableColours(productName);
		if (availableColours != null)
			return Response.status(Response.Status.OK).entity(availableColours).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	/**
	 * we can't use @GET because the productName contains spaces
	 * 
	 * @return a response which contains a list of sizes (Strings)
	 */
	@POST
	@Path("/available-sizes")
	public Response getAllAvailableSizes(String productName) {
		List<String> availableSizes = productDAO.findAllAvailableSizes(productName);
		if (availableSizes != null)
			return Response.status(Response.Status.OK).entity(availableSizes).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	/**
	 * we can't use @GET because the search string can contain spaces
	 * 
	 * @return a response which contains a list of the found products
	 */
	@POST
	@Path("/search")
	public Response getAllProductsBySearch(String search) {
		List<Product> foundProducts = productDAO.findAllProductsBySearch(search);
		if (foundProducts != null)
			return Response.status(Response.Status.OK).entity(foundProducts).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@PUT
	@Path("/{id}")
	public Product update(Product product, @PathParam("id") Long id) {
		if (id == product.getId())
			return productDAO.updateProduct(id, product);
		return null;
	}

	@DELETE
	@Path("/{id}")
	public void deleteUser(@PathParam("id") Long id) {
		productDAO.deleteProduct(id);
	}

	@Inject
	public void setBankAccountDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

}
