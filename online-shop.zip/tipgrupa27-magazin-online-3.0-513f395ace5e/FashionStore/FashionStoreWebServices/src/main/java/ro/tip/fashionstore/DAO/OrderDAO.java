package ro.tip.fashionstore.DAO;
import java.util.List;

import ro.tip.fashionstore.model.Orders;

public interface OrderDAO {
	Orders createOrder(Orders order);

	Orders findOrder(long id);

	Orders updateOrder(long id, Orders order);

	List<Orders> findAll();

	void deleteOrder(long id);
}