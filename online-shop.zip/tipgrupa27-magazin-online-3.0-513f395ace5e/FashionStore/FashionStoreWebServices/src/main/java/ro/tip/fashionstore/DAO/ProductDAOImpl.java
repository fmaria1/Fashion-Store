package ro.tip.fashionstore.DAO;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import ro.tip.fashionstore.model.Product;

public class ProductDAOImpl implements ProductDAO {

	@Inject
	private EntityManager entityManager;

	@Override
	public Product createProduct(Product product) {

		entityManager.getTransaction().begin();
		product = entityManager.merge(product);
		entityManager.getTransaction().commit();
		return product;
	}

	@Override
	public Product findProduct(long id) {
		return entityManager.find(Product.class, id);
	}

	@Override
	public Product updateProduct(long id, Product product) {
		Product oldProduct = entityManager.find(Product.class, id);
		if (oldProduct != null) {
			product.setId(id);
			entityManager.getTransaction().begin();
			oldProduct = entityManager.merge(product);
			entityManager.getTransaction().commit();
			return oldProduct;
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> findAll() {
		return entityManager.createQuery("SELECT p FROM Product p").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> findAllProductsForMen() {
		return entityManager.createQuery("SELECT p FROM Product p WHERE Type='M'").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> findAllProductsForWomen() {
		return entityManager.createQuery("SELECT p FROM Product p WHERE Type='F'").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findAllAvailableColours(String productName) {
		return entityManager.createQuery("SELECT DISTINCT p.colour FROM Product p WHERE Name='" + productName + "'")
				.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findAllAvailableSizes(String productName) {
		return entityManager.createQuery("SELECT DISTINCT p.size FROM Product p WHERE Name='" + productName + "'")
				.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> findAllProductsBySearch(String search) {
		return entityManager
				.createQuery("SELECT p FROM Product p WHERE LOWER(Name) LIKE '%" + search.toLowerCase() + "%'")
				.getResultList();
	}

	@Override
	public void deleteProduct(long id) {
		Product product = entityManager.find(Product.class, id);
		entityManager.getTransaction().begin();
		entityManager.remove(product);
		entityManager.getTransaction().commit();
	}

}
