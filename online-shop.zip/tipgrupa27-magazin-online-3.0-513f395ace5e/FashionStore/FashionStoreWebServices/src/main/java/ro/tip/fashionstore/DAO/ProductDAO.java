
package ro.tip.fashionstore.DAO;

import java.util.List;

import ro.tip.fashionstore.model.Product;

public interface ProductDAO {
	Product createProduct(Product product);

	Product findProduct(long id);

	Product updateProduct(long id, Product product);

	List<Product> findAll();

	List<Product> findAllProductsBySearch(String search);

	List<Product> findAllProductsForMen();

	List<Product> findAllProductsForWomen();

	List<String> findAllAvailableColours(String productName);

	List<String> findAllAvailableSizes(String productName);

	void deleteProduct(long id);
}