package ro.tip.fashionstore.DAO;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import ro.tip.fashionstore.model.User;
import ro.tip.fashionstore.security.EncryptUtils;

public class UserDAOImpl implements UserDAO {

	@Inject
	private EntityManager entityManager;

	@Override
	public User createUser(User user) {
		String encryptedPassword;
		try {
			encryptedPassword = EncryptUtils.encrypt(user.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		user.setPassword(encryptedPassword);
		entityManager.getTransaction().begin();
		user = entityManager.merge(user);
		entityManager.getTransaction().commit();
		return user;
	}

	@Override
	public User findUser(long id) {
		return entityManager.find(User.class, id);
	}

	@Override
	public User updateUser(long id, User user) {
		String encryptedPassword;
		try {
			encryptedPassword = EncryptUtils.encrypt(user.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		user.setPassword(encryptedPassword);
		User oldUser = entityManager.find(User.class, id);
		if (oldUser != null) {
			user.setId(id);
			entityManager.getTransaction().begin();
			oldUser = entityManager.merge(user);
			entityManager.getTransaction().commit();
			return oldUser;
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<User> findAll() {
		return entityManager.createQuery("SELECT u FROM User u").getResultList();
	}

	@Override
	public void deleteUser(long id) {
		User user = entityManager.find(User.class, id);
		entityManager.getTransaction().begin();
		entityManager.remove(user);
		entityManager.getTransaction().commit();
	}

	@SuppressWarnings("unchecked")
	@Override
	public User checkUserCredentials(User user) {
		String encryptedPassword = "";
		try {
			encryptedPassword = EncryptUtils.encrypt(user.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		List<Integer> userIdList = (List<Integer>) entityManager
				.createNativeQuery("SELECT UserID FROM User WHERE Email='" + user.getEmail() + "' AND Password='"
						+ encryptedPassword + "';")
				.getResultList();
		if (userIdList == null || userIdList.size() == 0)
			return null;
		return entityManager.find(User.class, new Long(userIdList.get(0)));
	}

}