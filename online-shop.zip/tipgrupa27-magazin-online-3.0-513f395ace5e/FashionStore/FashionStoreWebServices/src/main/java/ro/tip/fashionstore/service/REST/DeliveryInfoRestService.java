package ro.tip.fashionstore.service.REST;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import ro.tip.fashionstore.DAO.DeliveryInfoDAO;
import ro.tip.fashionstore.model.DeliveryInfo;


@Path("/api/deliveries-info")
@Consumes (MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)

public class DeliveryInfoRestService {
	
	private DeliveryInfoDAO deliveryInfoDAO;
	
	@GET
	@Path("/dummy")
	public DeliveryInfo getDummyDeliveryInfo() {
		DeliveryInfo di = new DeliveryInfo();
		di.setName("name");
		di.setAddress("adress");
		di.setCity("city");
		di.setCountry("country");
		di.setPostalCode("postalcode");
		di.setPhoneNumber("phonenumber");
		return di;
	}
	
	@POST
	@Path("/add")
	public Response save(DeliveryInfo deliveryInfo) {
		return Response.ok(deliveryInfoDAO.createDeliveryInfo(deliveryInfo)).build();
	}
	
	@GET
	@Path("/{id}")
	public Response get(@PathParam("id") Long id) {
		DeliveryInfo deliveryInfo = deliveryInfoDAO.findDeliveryInfo(id);
		if (deliveryInfo != null)
			return Response.status(Response.Status.OK).entity(deliveryInfo).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}
	
	@PUT
	@Path("/{id}")
	public DeliveryInfo update(DeliveryInfo deliveryInfo, @PathParam("id") Long id) {
		if (id == deliveryInfo.getId())
			return deliveryInfoDAO.updateDeliveryInfo(id, deliveryInfo);
		return null;
	}

	@DELETE
	@Path("/{id}")
	public void deleteDeliveryInfo(@PathParam("id") Long id) {
		deliveryInfoDAO.deleteDeliveryInfo(id);
	}

	@Inject
	public void setDeliveryInfoDAO(DeliveryInfoDAO deliveryInfoDAO) {
		this.deliveryInfoDAO = deliveryInfoDAO;
	}

}