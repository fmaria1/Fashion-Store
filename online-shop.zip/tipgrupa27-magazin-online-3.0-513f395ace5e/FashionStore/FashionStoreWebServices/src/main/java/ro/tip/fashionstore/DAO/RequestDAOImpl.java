package ro.tip.fashionstore.DAO;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import ro.tip.fashionstore.model.Request;

public class RequestDAOImpl implements RequestDAO {

		@Inject
		private EntityManager entityManager;	

		@Override
		public Request createRequest(Request request) {
			entityManager.getTransaction().begin();
			request = entityManager.merge(request);
			entityManager.getTransaction().commit();
			return request;
		}

		@Override
		public Request findRequest(long id) {
			return entityManager.find(Request.class, id);
		}

		@Override
		public Request updateRequest(long id, Request request) {
			Request oldRequest = entityManager.find(Request.class, id);
			if (oldRequest != null) {
				request.setId(id);
				entityManager.getTransaction().begin();
				oldRequest = entityManager.merge(request);
				entityManager.getTransaction().commit();
				return oldRequest;
			}
			return null;
		}

		@Override
		@SuppressWarnings("unchecked")
		public List<Request> findAll() {
			return entityManager.createQuery("SELECT ba FROM Request ba").getResultList();
		}

		@Override
		public void deleteRequest(long id) {
			Request request = entityManager.find(Request.class, id);
			entityManager.getTransaction().begin();
			entityManager.remove(request);
			entityManager.getTransaction().commit();
		}

	}