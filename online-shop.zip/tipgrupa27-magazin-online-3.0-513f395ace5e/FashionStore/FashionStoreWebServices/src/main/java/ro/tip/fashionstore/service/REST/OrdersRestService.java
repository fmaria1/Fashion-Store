package ro.tip.fashionstore.service.REST;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.OPTIONS;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import ro.tip.fashionstore.DAO.BankAccountDAO;
import ro.tip.fashionstore.DAO.OrderDAO;
import ro.tip.fashionstore.DAO.ProductDAO;
import ro.tip.fashionstore.DAO.UserDAO;
import ro.tip.fashionstore.model.BankAccount;
import ro.tip.fashionstore.model.Orders;
import ro.tip.fashionstore.model.Product;

@Path("/api/orders")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class OrdersRestService {
	// http://localhost:8080/FashionStoreWebServices/api/orders

	private OrderDAO orderDAO;

	@Inject
	private ProductDAO productDAO;

	// fields needed for the payment
	@Inject
	private BankAccountDAO bankAccountDAO;
	@Inject
	private UserDAO userDAO;

	/**
	 * Allow headers on all paths
	 */
	@OPTIONS
	public void getAccess(@Context HttpServletResponse response) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type");
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
	}

	@OPTIONS
	@Path("/order={id}")
	public void getAccessOrderId(@Context HttpServletResponse response) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type");
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
	}

	@GET
	@Path("/dummy")
	public Orders getDummyOrder() {
		Orders o = new Orders(1l, 1l, 20, 200.35);
		o.setId(1l);
		return o;
	}

	@POST
	public Response save(Orders order) {
		// update stock for the specified product
		Product product = productDAO.findProduct(order.getProductId());
		product.setStock(product.getStock() - order.getQuantity());
		productDAO.updateProduct(product.getId(), product);

		long bankAccountId = userDAO.findUser(order.getUserId()).getAccountId();
		BankAccount bankAccount = bankAccountDAO.findBankAccount(bankAccountId);
		// use the bank account info to effectuate the payment
		System.out.println(bankAccount);

		return Response.ok(orderDAO.createOrder(order)).build();
	}

	@GET
	@Path("/order={id}")
	public Response get(@PathParam("id") Long id) {
		Orders order = orderDAO.findOrder(id);
		if (order != null)
			return Response.status(Response.Status.OK).entity(order).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@GET
	public Response getAll() {
		List<Orders> ordersList = orderDAO.findAll();
		if (ordersList != null)
			return Response.status(Response.Status.OK).entity(ordersList).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@PUT
	@Path("/order={id}")
	public Orders update(Orders order, @PathParam("id") Long id) {
		if (id == order.getId())
			return orderDAO.updateOrder(id, order);
		return null;
	}

	@DELETE
	@Path("/order={id}")
	public void deleteOrder(@PathParam("id") Long id) {
		orderDAO.deleteOrder(id);
	}

	@Inject
	public void setOrderDAO(OrderDAO orderDAO) {
		this.orderDAO = orderDAO;
	}
}
