package ro.tip.fashionstore.service.REST;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.OPTIONS;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import ro.tip.fashionstore.DAO.UserDAO;
import ro.tip.fashionstore.model.User;

@Path("/api/users")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class UserRestService {
	// http://localhost:8080/FashionStoreWebServices/api/users

	private UserDAO userDAO;

	/**
	 * Allow headers on all paths
	 */
	@OPTIONS
	public void getAccess(@Context HttpServletResponse response) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type");
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
	}

	@OPTIONS
	@Path("/user={id}")
	public void getAccessUserId(@Context HttpServletResponse response) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type");
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
	}

	@OPTIONS
	@Path("/check")
	public void getAccessCheck(@Context HttpServletResponse response) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type");
		response.setHeader("Access-Control-Allow-Methods", "POST");
	}

	@GET
	@Path("/dummy")
	public User getDummyUser() {
		User u = new User();
		u.setAccountId(1l);
		u.setAdmin(false);
		u.setDeliveryInfoId(1l);
		u.setEmail("ion_popescu@gmail.com");
		u.setId(1l);
		u.setPassword("password");
		u.setUsername("Johnny");
		return u;
	}

	@POST
	public Response save(User user) {
		return Response.ok(userDAO.createUser(user)).build();
	}

	@POST
	@Path("/check")
	public Response checkCredentials(User user) {
		return Response.ok(userDAO.checkUserCredentials(user)).build();
	}

	@GET
	@Path("/user={id}")
	public Response get(@PathParam("id") Long id) {
		User user = userDAO.findUser(id);
		if (user != null)
			return Response.status(Response.Status.OK).entity(user).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@GET
	public Response getAll() {
		List<User> userList = userDAO.findAll();
		if (userList != null)
			return Response.status(Response.Status.OK).entity(userList).build();

		return Response.status(Response.Status.BAD_REQUEST).build();
	}

	@PUT
	@Path("/user={id}")
	public User update(User user, @PathParam("id") Long id) {
		if (id == user.getId())
			return userDAO.updateUser(id, user);
		return null;
	}

	@DELETE
	@Path("/user={id}")
	public void deleteUser(@PathParam("id") Long id) {
		userDAO.deleteUser(id);
	}

	@Inject
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
}