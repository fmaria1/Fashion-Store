package ro.tip.fashionstore.DAO;

import java.util.List;

import ro.tip.fashionstore.model.Request;

public interface RequestDAO {
	Request createRequest(Request request);

	Request findRequest(long id);

	Request updateRequest(long id, Request request);

	List<Request> findAll();

	void deleteRequest(long id);
}
