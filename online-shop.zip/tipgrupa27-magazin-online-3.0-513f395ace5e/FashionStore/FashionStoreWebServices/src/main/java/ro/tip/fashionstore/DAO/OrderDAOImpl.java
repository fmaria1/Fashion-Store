package ro.tip.fashionstore.DAO;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import ro.tip.fashionstore.model.Orders;

public class OrderDAOImpl implements OrderDAO {

	@Inject
	private EntityManager entityManager;	

	@Override
	public Orders createOrder(Orders Order) {
		entityManager.getTransaction().begin();
		Order = entityManager.merge(Order);
		entityManager.getTransaction().commit();
		return Order;
	}

	@Override
	public Orders findOrder(long id) {
		return entityManager.find(Orders.class, id);
	}

	@Override
	public Orders updateOrder(long id, Orders order) {
		Orders oldOrder = entityManager.find(Orders.class, id);
		if (oldOrder != null) {
			order.setId(id);
			entityManager.getTransaction().begin();
			oldOrder = entityManager.merge(order);
			entityManager.getTransaction().commit();
			return oldOrder;
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Orders> findAll() {
		return entityManager.createQuery("SELECT o FROM Orders o").getResultList();
	}

	@Override
	public void deleteOrder(long id) {
		Orders order = entityManager.find(Orders.class, id);
		entityManager.getTransaction().begin();
		entityManager.remove(order);
		entityManager.getTransaction().commit();
	}

}