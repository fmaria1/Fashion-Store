2USE mysql;
CREATE USER 'admin'@'localhost' IDENTIFIED BY 'adminpw';
GRANT ALL PRIVILEGES on *.* to 'admin'@'localhost';

CREATE DATABASE fashionstore;
USE fashionstore;

CREATE TABLE DeliveryInfo(DeliveryInfoID INT NOT NULL AUTO_INCREMENT,
						  Name VARCHAR(150),
						  Address VARCHAR(150),
						  City VARCHAR(50),
						  Country VARCHAR(50),
						  PostalCode VARCHAR(10),
						  PhoneNumber CHAR(10),
						  PRIMARY KEY(DeliveryInfoID));

CREATE TABLE Product(ProductID INT NOT NULL AUTO_INCREMENT,
					 Name VARCHAR(150),
					 Stock TINYINT UNSIGNED,
					 Description VARCHAR(600), 
					 Type VARCHAR(1),
					 Price DECIMAL(6, 2),
					 Size VARCHAR(5),
					 Category VARCHAR(50),
					 Colour VARCHAR(50),
					 ImagePath VARCHAR(200),
					 PRIMARY KEY(ProductID));

CREATE TABLE BankAccount(AccountID INT NOT NULL AUTO_INCREMENT,
						 CardNumber CHAR(16),
						 ExpirationDate DATE,
						 CvvCode DECIMAL(3),
						 PRIMARY KEY(AccountID));

CREATE TABLE User(UserID INT NOT NULL AUTO_INCREMENT,
				  Username VARCHAR(30),
				  Email VARCHAR(30),
		 		  Password VARCHAR(30),
		  		  AccountID INT,
		  		  DeliveryInfoID INT,
		  		  Admin BOOL,
		  		  PRIMARY KEY (UserID),
		  		  FOREIGN KEY (AccountID) REFERENCES BankAccount(AccountID),
		    	  FOREIGN KEY (DeliveryInfoID) REFERENCES DeliveryInfo(DeliveryInfoID));

CREATE TABLE Orders (OrderID INT NOT NULL AUTO_INCREMENT,
					ProductID INT,
					Quantity TINYINT UNSIGNED,
					UserID INT,
					Cost DECIMAL(7,2),
					PRIMARY KEY(OrderID),
					FOREIGN KEY (ProductID) REFERENCES Product (ProductID),
					FOREIGN KEY (UserID) REFERENCES User (UserID));

CREATE TABLE Request(RequestID INT NOT NULL AUTO_INCREMENT,
					 ProductID INT NOT NULL,
					 NoOfRequests INT,
					 RequestStatus BOOLEAN,
					 PRIMARY KEY(RequestID),
					 FOREIGN KEY (ProductID) REFERENCES Product (ProductID));

INSERT INTO BankAccount(CardNumber, ExpirationDate, CvvCode) values('1234123412341234',STR_TO_DATE('23-10-2020', '%d-%m-%Y'), 123);
INSERT INTO BankAccount(CardNumber, ExpirationDate, CvvCode) values('2345234523452345',STR_TO_DATE('03-03-2020', '%d-%m-%Y'), 234);
INSERT INTO BankAccount(CardNumber, ExpirationDate, CvvCode) values('3456345634563456',STR_TO_DATE('01-01-2018', '%d-%m-%Y'), 345);
INSERT INTO BankAccount(CardNumber, ExpirationDate, CvvCode) values('4567456745674567',STR_TO_DATE('09-04-2018', '%d-%m-%Y'), 456);
INSERT INTO BankAccount(CardNumber, ExpirationDate, CvvCode) values('5678567856785678',STR_TO_DATE('15-12-2022', '%d-%m-%Y'), 567);

INSERT INTO DeliveryInfo(Name, Address, City, Country, PostalCode, PhoneNumber) values('Maria Frentescu', 'address1', 'Bucuresti', 'Romania', '523986', '0235123412');
INSERT INTO DeliveryInfo(Name, Address, City, Country, PostalCode, PhoneNumber) values('Florina Bejan', 'address2', 'Arad', 'Romania', '375190', '0732195230');
INSERT INTO DeliveryInfo(Name, Address, City, Country, PostalCode, PhoneNumber) values('Teodora Luca', 'address3', 'Brasov', 'Romania', '918126', '0764983267');
INSERT INTO DeliveryInfo(Name, Address, City, Country, PostalCode, PhoneNumber) values('Ana Popescu', 'address4', 'Sibiu', 'Romania', '492589', '0235123412');
INSERT INTO DeliveryInfo(Name, Address, City, Country, PostalCode, PhoneNumber) values('Bostan Diana', 'address5', 'Craiova', 'Romania', '183653', '0235123412');

INSERT INTO User(Username, Email, Password, AccountID, DeliveryInfoID, Admin) values('User1','user1@gmail.com', 'tegAIve6iah99mBaapTCyg==', 1,1,1);
INSERT INTO User(Username, Email, Password, AccountID, DeliveryInfoID, Admin) values('User2','user2@gmail.com', 'wcBdJyjN250bZls5RUYGAQ==', 2,2,0);
INSERT INTO User(Username, Email, Password, AccountID, DeliveryInfoID, Admin) values('User3','user3@gmail.com', 'ezdagZy9Zzc4G11IJRH6BA==', 1,1,0);
INSERT INTO User(Username, Email, Password, AccountID, DeliveryInfoID, Admin) values('User4','user4@gmail.com', 'AvzRNF2NC2fKs3MI/DO3kA==', 1,1,0);
INSERT INTO User(Username, Email, Password, AccountID, DeliveryInfoID, Admin) values('User5','user5@gmail.com', 'kQiJagMxoyQ47wHzHEMAIg==', 1,1,0);

INSERT INTO BankAccount(CardNumber,ExpirationDate,CvvCode) VALUES ("1111222233334444",'2020-01-01',123);
INSERT INTO BankAccount(CardNumber,ExpirationDate,CvvCode) VALUES ("1122334455667788",'2021-01-01',942);
INSERT INTO BankAccount(CardNumber,ExpirationDate,CvvCode) VALUES ("9123659175357902",'2019-02-06',472);

INSERT INTO Product (Name,Stock,Description,Type,Price,Size, Category, Colour, imagePath) VALUES
 ("Carmel Gown",14,"Textural appliques adorn the bodice and float down through the full skirt, crafted from layers of glitter tulle. A plunge neckline adds a sultry edge to the whimsical look, and a removable grosgrain belt defines the waist","M",1400,"S","Dress","White ivory", "images/dress1.jpg"),
 ("Milano Gown",20,"Soft lace is swathed in ivory floral embroidery, perfectly placed to highlight your best assets. The v-neckline and delicate flutter sleeves give way to a sexy open back, while a frothy train completes the look.","M",1290,"M", "Dress", "White ivory/nude","images/dress2.jpg"),
 ("Lange Gown",10,"Whimsy meets sultry with the floral lace bodice of this romantic gown courtesy of a low back and plunging neckline with sheer mesh panel. A twirlable A-line tulle skirt and blush satin ribbon complete the look","M",50,"S", "Dress", "White ivory/blush","images/dress3.jpg" ),
 ("Valera Gown",25,"A floral-embroidered bodice features a plunging neckline and sheer back for a stunning finish, but our favorite part of this showstopping ballgown is its voluminous tiered skir","M",60,"Polyester","Dress","M", "images/dress4.jpg"),
 ("Naomi Gown",23,"Intricate, deco-inspired beading brings the 1920s to life in this gown. Artfully placed tulle panels that sway with every step add dimension and glamour","M",800,"M","Dress","ivory", "images/dress5.jpg"),
 ("Hyde Gown",25,"A plunging back and sheer mesh panels lend a sultry vibe to this sleek crepe sheath. With a high-neckline and a figure-flattering fit, it's minimalism at its best.","M",850,"M","Dress","Ivory", "images/dress6.jpg"),
 ("Capricorn Gown",15,"Tulle godets lend a feathery fullness to the skirt of this figure-flattering gown, which layers feminine floral embroidery over Swiss dot tulle. A sheer neckline completes the look.","M",1700,"S","Dress","Ivory/nude", "images/dress7.jpg"),
 ("Cassia Gown",10,"Trimmed in sparkle, this effortless v-neck gown exudes romance. Intricate illusion lace, replete with glistening beads, ascends from the bodice and a frothy tulle skirt finishes the look. A bonus: pearl buttons down the back!","M",1150,"S","Dress","Ivory/Champagne", "images/dress8.jpg"),
 ("Octavia Gown",23,"This taffeta gown features a deep v-neckline and a strappy open back accented with angular illusion panels.The full A-line skirt extends into a sweeping train","M",975,"M","Dress","Ivory", "images/dress9.jpg"),
 ("Hearst Gown",14,"Oversized floral appliques accent this gown's fitted bodice and float down the frothy A-line skirt, which extends into a slight train. A deep v-neckline, open back, and side cutouts reveal a bit of skin while two straps accentuate the waist","M",1195,"S","Dress","Silver", "images/dress10.jpg"),
  ("Beloved Gown",20,"The crisp v-neck front of this gown gives way to a sheer lace back and dramatic train","Polyester",1350,"M","Dress","Ivory", "images/dress11.jpg");

INSERT INTO Product (Name,Stock,Description,Type,Price,Size, Category, Colour, imagePath) VALUES
  ("Renny Stud Earrings",20,"Surrounded with tiny crystals, an oval-cut Swarovski stone shines bright on this radiant pair.","F",65,"One size","Earings","Silver","images/acs1.jpg"),
	("Ranita Stud Earrings",25,"A cluster of champagne and blush stones in an array of shapes and sizes lend a festive finish to clip-on studs.","F",65,"One size","Earings","Silver","images/acs2.jpg"),
	("Kaira Stud Earrings",14,"Square-cut Swarovski crystals in a selection of sparkling hues are perfect for gifting to your maids to wear on the big day.","F",45,"One size","Earings","Light blue","images/acs3.jpg"),
	("Crystal Fronds Hair Pin",20,"Swarovksi crystals accent the delicate branches of this rose gold hair pin.","F",85,"One size","Hair pin","Rose","images/acs4.jpg"),
	("Weatherby Barrette",24,"Clusters of faceted clear and opalescent stones lend major sparkle to this floral-inspired barrette","F",50,"One size","Hair pin","Gold","images/acs5.jpg"),
	("Jaleesa Necklace",10,"Alternating teardrop and oval-cut stones combine for this utterly glamorous necklace.","F",195,"One size","Necklace","Silver","images/acs6.jpg"),
	("Kay Crystal Pendant Necklace",34,"A faceted oval stone is a minimalist yet glam accent to this slim silver chain","F",55,"One size","Necklace","Silver","images/acs7.jpg"),
	("Val Bracelet",45,"Understated yet oh-so-sparkly, this crystal-encrusted bracelet features a slim chain with circular accents.","F",100,"One size","Necklace","Silver","images/acs8.jpg");



INSERT INTO Orders (ProductID, UserID, Quantity,Cost) VALUES (1,2,2,120);
INSERT INTO Orders (ProductID, UserID, Quantity,Cost) VALUES (2,3,1,10);
INSERT INTO Orders (ProductID, UserID, Quantity,Cost) VALUES (3,4,2,100);

INSERT INTO Request (ProductID,NoOfRequests,RequestStatus) VALUES (1,1,1);
INSERT INTO Request (ProductID,NoOfRequests,RequestStatus) VALUES (2,4,0);
INSERT INTO Request (ProductID,NoOfRequests,RequestStatus) VALUES (3,2,1);
