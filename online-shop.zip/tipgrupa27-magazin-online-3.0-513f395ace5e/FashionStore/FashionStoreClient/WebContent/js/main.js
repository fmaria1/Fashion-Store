jQuery(document).ready(function($){
	var tabItems = $('.cd-tabs-navigation a'),
		tabContentWrapper = $('.cd-tabs-content');

	tabItems.on('click', function(event){
		event.preventDefault();
		var selectedItem = $(this);
		if( !selectedItem.hasClass('selected') ) {
			var selectedTab = selectedItem.data('content'),
				selectedContent = tabContentWrapper.find('li[data-content="'+selectedTab+'"]'),
				slectedContentHeight = selectedContent.innerHeight();
			
			tabItems.removeClass('selected');
			selectedItem.addClass('selected');
			selectedContent.addClass('selected').siblings('li').removeClass('selected');
			//animate tabContentWrapper height when content changes 
			tabContentWrapper.animate({
				'height': slectedContentHeight
			}, 200);
		}
	});

	//hide the .cd-tabs::after element when tabbed navigation has scrolled to the end (mobile version)
	checkScrolling($('.cd-tabs nav'));
	$(window).on('resize', function(){
		checkScrolling($('.cd-tabs nav'));
		tabContentWrapper.css('height', 'auto');
	});
	$('.cd-tabs nav').on('scroll', function(){ 
		checkScrolling($(this));
	});

	function checkScrolling(tabs){
		var totalTabWidth = parseInt(tabs.children('.cd-tabs-navigation').width()),
		 	tabsViewport = parseInt(tabs.width());
		if( tabs.scrollLeft() >= totalTabWidth - tabsViewport) {
			tabs.parent('.cd-tabs').addClass('is-ended');
		} else {
			tabs.parent('.cd-tabs').removeClass('is-ended');
		}
	}
});

function changeTheDisplayedProductDetails(section){
	var additionalInfoButton = document.getElementById("additionalInfoButton");
	var descriptionButton = document.getElementById("descriptionButton");
	var descriptionContent = document.getElementById("description");
	var additionalInfoContent = document.getElementById("additionalInfo");
	if(section=="Desccription")
	{
		additionalInfoButton.className="";
		additionalInfoContent.className="";
		descriptionButton.className="selected";
		descriptionContent.className="selected";
	}
	else {
		additionalInfoButton.className="selected";
		additionalInfoContent.className="selected";
		descriptionButton.className="";
		descriptionContent.className="";
	}
}

function showMyImage(fileInput) {
	console.log("ok");
	var files = fileInput.files;
	for (var i = 0; i < files.length; i++) {           
		var file = files[i];
		var imageType = /image.*/;     
		if (!file.type.match(imageType)) {
			continue;
		}           
		var img=document.getElementById("preview");            
		img.file = file;    
		var reader = new FileReader();
		reader.onload = (function(aImg) { 
			return function(e) { 
				aImg.src = e.target.result; 
			}; 
		})(img);
		reader.readAsDataURL(file);
	}    
}

function checkPass() {
	var newPass=document.getElementById("new_pass").value
	var confirmPass=document.getElementById("confirm_pass").value;
	if(newPass==confirmPass && newPass.length>=5)
		return true;
	if(newPass!=confirmPass)
		alert("Passwords don't match!");
	if(newPass.length<5)
		alert("Password too weak! The password should contain at least 5 characters!")
	return false;
}