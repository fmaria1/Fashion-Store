package ro.tip.fashionstore.servlet;

import java.io.IOException;
import java.net.URI;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import ro.tip.fashionstore.model.User;

/**
 * Servlet implementation class AccessHelper
 */
@WebServlet(description = "Connector for auth server", urlPatterns = { "/get-auth-token", "/logout" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String loginSuccessPage = "/FashionStoreClient/";
	private static final String loginFailedPage = "/FashionStoreClient/login.jsp";
	private ClientConfig config;
	private Client client;
	private WebTarget service;
	private Response response;

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/FashionStoreWebServices/").build();
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		config = new ClientConfig();
		client = ClientBuilder.newClient(config);
		service = client.target(getBaseURI());
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println(request.getRequestURL());
		if (request.getRequestURL().toString().contains("logout")) {
			request.getSession().invalidate();
			response.sendRedirect("/FashionStoreClient/");
			return;
		}
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String responsePage = loginFailedPage;
		String userID = null;
		String userRights = null;
		HttpSession session = request.getSession();

		String providedEmail = request.getParameter("email");
		String providedPassword = request.getParameter("pass");

		User user = new User();
		user.setEmail(providedEmail);
		user.setPassword(providedPassword);
		this.response = service.path("api").path("users").path("check").request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(user, MediaType.APPLICATION_JSON), Response.class);

		User loggedUser = this.response.readEntity(User.class);
		if (loggedUser != null) {
			userID = "" + loggedUser.getId();
			if (loggedUser.getAdmin())
				userRights = "" + loggedUser.getUsername().toString().hashCode();
			responsePage = loginSuccessPage;
			session.setAttribute("username", loggedUser.getUsername());
			session.removeAttribute("privileges");
		} else {
			session.setAttribute("err-msg", "Login failed. Bad email or password.");
		}
		session.setAttribute("userID", userID);
		if (userRights != null)
			session.setAttribute("privileges", userRights);
		response.sendRedirect(responsePage);
	}

}
