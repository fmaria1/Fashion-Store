package ro.tip.fashionstore.servlet;

import java.io.IOException;
import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import ro.tip.fashionstore.model.BankAccount;
import ro.tip.fashionstore.model.DeliveryInfo;
import ro.tip.fashionstore.model.User;

@WebServlet(description = "Register new user", urlPatterns = { "/register" })
public class RegisterServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String registerSuccessPage = "/FashionStoreClient";
	private static final String registerFailedPage = "/FashionStoreClient/register.jsp";
	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	private ClientConfig config;
	private Client client;
	private WebTarget service;
	private Response response;

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/FashionStoreWebServices/").build();
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
		config = new ClientConfig();
		client = ClientBuilder.newClient(config);
		service = client.target(getBaseURI());
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	private BankAccount getProvidedBankAccountInfo(HttpServletRequest request) {
		String providedCardNumber = request.getParameter("card");
		int providedCvvCode = Integer.valueOf(request.getParameter("cvv"));
		String stringDate = request.getParameter("expire");
		Date providedExpiringDate = null;
		try {
			providedExpiringDate = format.parse(stringDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (providedExpiringDate != null)
			return new BankAccount(providedCardNumber, providedCvvCode, providedExpiringDate);
		return null;
	}

	private DeliveryInfo getProvidedDeliveryInfo(HttpServletRequest request) {
		String providedName = request.getParameter("full_name");
		String providedAddress = request.getParameter("address");
		String providedCity = request.getParameter("city");
		String providedCountry = request.getParameter("country");
		String providedPostalCode = request.getParameter("postal_code");
		String providedPhoneNumber = request.getParameter("tel");
		return new DeliveryInfo(providedName, providedAddress, providedCity, providedCountry, providedPostalCode,
				providedPhoneNumber);
	}

	private User getProvidedUser(HttpServletRequest request) {
		String providedUsername = request.getParameter("username");
		String providedPassword = request.getParameter("pass");
		String providedConfirmPassword = request.getParameter("confirm");
		String providedEmail = request.getParameter("email");
		User user = null;
		if (providedPassword.equals(providedConfirmPassword))
			user = new User(0, 0, providedUsername, providedPassword, providedEmail, false);
		return user;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String responsePage = registerFailedPage;
		HttpSession session = request.getSession();
		DeliveryInfo deliveryInfo = getProvidedDeliveryInfo(request);
		BankAccount bankAccount = getProvidedBankAccountInfo(request);
		User user = getProvidedUser(request);

		this.response = service.path("api").path("deliveries-info").path("add").request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(deliveryInfo, MediaType.APPLICATION_JSON), Response.class);
		deliveryInfo = this.response.readEntity(DeliveryInfo.class); // get the id

		this.response = service.path("api").path("bank-accounts").path("add").request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(bankAccount, MediaType.APPLICATION_JSON), Response.class);
		bankAccount = this.response.readEntity(BankAccount.class); // get the id

		if (deliveryInfo == null) {
			session.setAttribute("err-msg", "Register failed. Invalid delivery information.");
			response.sendRedirect(responsePage);
			return;
		} else if (bankAccount == null) {
			session.setAttribute("err-msg", "Register failed. Invalid bank account information.");
			response.sendRedirect(responsePage);
			return;
		} else {
			user.setAccountId(bankAccount.getId());
			user.setDeliveryInfoId(deliveryInfo.getId());
			this.response = service.path("api").path("users").request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(user, MediaType.APPLICATION_JSON), Response.class);
			user = this.response.readEntity(User.class); // get the id
		}

		if (user != null) {
			responsePage = registerSuccessPage;
		} else {
			session.setAttribute("err-msg", "Register failed. Invalid account information.");
		}
		response.sendRedirect(responsePage);
	}
}
