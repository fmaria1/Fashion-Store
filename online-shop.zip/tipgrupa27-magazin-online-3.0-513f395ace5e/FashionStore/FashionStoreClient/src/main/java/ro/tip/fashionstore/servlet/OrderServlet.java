package ro.tip.fashionstore.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import ro.tip.fashionstore.model.Orders;


/**
 * Servlet implementation class OrderServlet
 */
@WebServlet(name = "OrderServlet", urlPatterns = {"/orders"})
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClientConfig config;
	private Client client;
	private WebTarget service;
	private Response response;
	
	private static URI getBaseURI() {
        return UriBuilder.fromUri("http://localhost:8080/FashionStoreWebServices/").build();
    }
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        config = new ClientConfig();
        client = ClientBuilder.newClient(config);
        service = client.target(getBaseURI());
    }
    
    private void appendTableLine(PrintWriter pw, Orders order)
    {
    	pw.append("<tr>\n" + 
				"    <td>"+order.getCost()+"</td>\n" + 
				"    <td>"+order.getId()+"</td>\n" + 
				"    <td>"+order.getProductId()+"</td>\n" +
				"    <td>"+order.getQuantity()+"</td>\n" + 
				"    <td>"+order.getUserId()+"</td>\n" + 
				"    </tr>");
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.response = service.path("api").path("orders").request().accept(MediaType.APPLICATION_JSON).get(Response.class);
		PrintWriter writer = response.getWriter();
		writer.append("<!DOCTYPE html>\n" + 
				"<html lang='ro'>\n" + 
				"<head>\n" + 
				"	<title>Fashion Store</title>\n" + 
				"	<meta charset='utf-8'/>\n" + 
				"	<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n" + 
				"	<link rel='stylesheet' type='text/css' href='css/style.css'/>\n" + 
				"</head>\n" + 
				"<body>");
		writer.append("<h1>Lista de comenzi</h1>");
		writer.append("<table id='orders'>\n" +
						"    <tr>\n" +
						"    <th>Cost</th>\n" +
						"    <th>OrderId</th>\n" +
						"    <th>ProductId</th>\n" +
						"    <th>Quantity</th>\n" +
						"    <th>UserId</th>\n" +
						"   </tr>");
		@SuppressWarnings("unchecked")
		List<LinkedHashMap<String, Object>> list=this.response.readEntity(List.class);
		for (LinkedHashMap<String, Object> linkedHashMap : list) {
			double cost=(double)linkedHashMap.get("cost");
			Long id=new Long((Integer)linkedHashMap.get("id"));
			Long productId=new Long((Integer)linkedHashMap.get("productId"));
			Long userId=new Long((Integer)linkedHashMap.get("userId"));
			int quantity=(int)linkedHashMap.get("quantity");
			Orders order=new Orders(productId,userId,quantity,cost);
			order.setId(id);
			appendTableLine(writer,order);
		}
		writer.append("</table></body>");
		writer.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
