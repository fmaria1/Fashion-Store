package ro.tip.fashionstore.servlet;

import java.io.IOException;
import java.net.URI;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import ro.tip.fashionstore.model.Product;

@WebServlet(description = "show product details", urlPatterns = { "/products/*" })
public class ProductDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClientConfig config;
	private Client client;
	private WebTarget service;
	private Response response;

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/FashionStoreWebServices/").build();
	}

	private static long getProductIdFromUrl(String url) {
		String[] result = url.split("/");
		int length = result.length;
		try {
			// 10 is the base of the product id which we want to parse
			return Long.parseLong(result[length - 1], 10);
		} catch (NumberFormatException e) {
			return -1L;
		}
	}

	public ProductDetailsServlet() {
		super();
		config = new ClientConfig();
		client = ClientBuilder.newClient(config);
		service = client.target(getBaseURI());
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = request.getRequestURL().toString();
		long productId = getProductIdFromUrl(url);
		if (productId == -1)
			return;
		this.response = service.path("api").path("products").path("" + productId).request()
				.accept(MediaType.APPLICATION_JSON).get(Response.class);
		Product currentProduct = this.response.readEntity(Product.class);
		if (currentProduct == null)
			return;
		this.response = service.path("api").path("products").path("available-colours").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(currentProduct.getName(), MediaType.APPLICATION_JSON), Response.class);
		@SuppressWarnings("unchecked")
		List<String> availableColours = (List<String>) this.response.readEntity(List.class);

		this.response = service.path("api").path("products").path("available-sizes").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(currentProduct.getName(), MediaType.APPLICATION_JSON), Response.class);
		@SuppressWarnings("unchecked")
		List<String> availableSizes = (List<String>) this.response.readEntity(List.class);

//		System.out.println(availableColours);
//		System.out.println(availableSizes);
//		System.out.println(currentProduct);

		request.setAttribute("currentProduct", currentProduct);
		request.setAttribute("availableColours", availableColours);
		request.setAttribute("availableSizes", availableSizes);

		request.getRequestDispatcher("/single.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
