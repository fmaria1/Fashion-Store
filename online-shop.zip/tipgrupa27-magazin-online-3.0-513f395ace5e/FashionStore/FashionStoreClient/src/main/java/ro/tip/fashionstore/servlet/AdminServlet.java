package ro.tip.fashionstore.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.glassfish.jersey.client.ClientConfig;

import ro.tip.fashionstore.model.Product;

@WebServlet(name = "adminServlet", urlPatterns = { "/add-product", "/submit-product", "/edit-product/*",
		"/delete-product", "/delete-product/*" })
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClientConfig config;
	private Client client;
	private WebTarget service;
	private Response response;

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/FashionStoreWebServices/").build();
	}

	private static long getProductIdFromUrl(String url) {
		String[] result = url.split("/");
		int length = result.length;
		try {
			// 10 is the base of the product id which we want to parse
			return Long.parseLong(result[length - 1], 10);
		} catch (NumberFormatException e) {
			return -1L;
		}
	}

	private String getPathToWebContent() {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		URL url = classLoader.getResource("");
		File file;
		try {
			file = new File(url.toURI());
			String path = file.toPath().toString();
			String x = path.substring(0, path.indexOf(".metadata") - 1);
			return x + "/FashionStore/FashionStoreClient/WebContent";
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return null;
	}

	public AdminServlet() {
		super();
		config = new ClientConfig();
		client = ClientBuilder.newClient(config);
		service = client.target(getBaseURI());
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (session.getAttribute("privileges") != null) {

			String url = request.getRequestURL().toString();
			String landingPage = "/WEB-INF/administrativePage.jsp";
			if (url.contains("add-product"))
				landingPage = "/WEB-INF/administrativePage.jsp";
			else if (url.contains("edit-product")) {
				landingPage = "/WEB-INF/administrativePage.jsp";
				long productId = getProductIdFromUrl(url);
				if (productId == -1)
					return;
				this.response = service.path("api").path("products").path("" + productId).request()
						.accept(MediaType.APPLICATION_JSON).get(Response.class);
				Product currentProduct = this.response.readEntity(Product.class);
				if (currentProduct == null)
					return;
				request.setAttribute("currentProductAdm", currentProduct);
				session.setAttribute("currentProductIdAdm", currentProduct.getId());
				session.setAttribute("currentProductImagePathAdm", currentProduct.getImagePath());
			} else if (url.contains("delete-product")) {
				landingPage = "/WEB-INF/administrativePage2.jsp";

				if (url.contains("delete-product/")) {
					long productId = getProductIdFromUrl(url);
					if (productId > -1)
						service.path("api").path("products").path("" + productId).request().delete();
					response.sendRedirect("/FashionStoreClient/delete-product");
					return;
				}

				this.response = service.path("api").path("products").request().accept(MediaType.APPLICATION_JSON)
						.get(Response.class);
				@SuppressWarnings("unchecked")
				List<LinkedHashMap<String, Object>> list = this.response.readEntity(List.class);

				List<Product> productList = new ArrayList<Product>();
				if (list == null)
					productList = null;
				else {
					for (LinkedHashMap<String, Object> linkedHashMap : list) {
						String name = (String) linkedHashMap.get("name");
						String description = (String) linkedHashMap.get("description");
						Double price = (Double) linkedHashMap.get("price");
						String size = (String) linkedHashMap.get("size");
						int stock = (Integer) linkedHashMap.get("stock");
						String productType = (String) linkedHashMap.get("type");
						String category = (String) linkedHashMap.get("category");
						String colour = (String) linkedHashMap.get("colour");
						String imagePath = (String) linkedHashMap.get("imagePath");
						char type = productType.charAt(0);
						Long productId = new Long((Integer) linkedHashMap.get("id"));
						Product product = new Product(name, description, price, size, stock, type, category, colour,
								imagePath);
						product.setId(productId);
						productList.add(product);
					}
				}

				request.setAttribute("productList", productList);
			}
			request.getRequestDispatcher(landingPage).forward(request, response);
		} else
			request.getRequestDispatcher("/FashionStoreClient/").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (session.getAttribute("privileges") != null) {

			String url = request.getRequestURL().toString();
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			if (isMultipart && url.contains("submit-product")) {
				List<FileItem> items;
				try {
					items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
					String productName = items.get(0).getString();
					int stock = Integer.parseInt(items.get(1).getString());
					String category = items.get(2).getString();
					String colour = items.get(3).getString();
					String description = items.get(4).getString();
					String type = items.get(5).getString();
					double price = Double.parseDouble(items.get(6).getString());
					String size = items.get(7).getString();

					String edit = items.get(9).getString(); // true or false if it's update or create new product
					// process form file field (input type="file")
					String filename = FilenameUtils.getName(items.get(8).getName());
					InputStream filecontent = items.get(8).getInputStream();

					Product product = new Product(productName, description, price, size, stock, type.charAt(0),
							category, colour, "");
					if (edit.equals("true")) {
						product.setId((Long) session.getAttribute("currentProductIdAdm"));
						product.setImagePath((String) session.getAttribute("currentProductImagePathAdm"));
					}

					// THESE LINES UPLOAD THE IMAGE TO THE /images folder
					File uploads = new File(getPathToWebContent() + "/images");
					File file = new File(uploads, filename);
					try {
						Files.copy(filecontent, file.toPath());
					} catch (FileAlreadyExistsException e) {
						// do nothing, the file already exists
						// you can overwrite it, if you want.
						System.out.println("File already exists. Rename it!");
					}

					if (filename != "")
						product.setImagePath("images/" + filename);
					System.out.println(product);

					if (edit.equals("false")) {
						// @POST
						this.response = service.path("api").path("products").path("add")
								.request(MediaType.APPLICATION_JSON)
								.post(Entity.entity(product, MediaType.APPLICATION_JSON), Response.class);
					} else if (edit.equals("true")) {
						// @PUT
						this.response = service.path("api").path("products").path("" + product.getId())
								.request(MediaType.APPLICATION_JSON)
								.put(Entity.entity(product, MediaType.APPLICATION_JSON), Response.class);
					}
					response.sendRedirect("/FashionStoreClient/delete-product");
					return;
				} catch (FileUploadException e) {
					e.printStackTrace();
				}

			} else
				doGet(request, response);
		} else
			request.getRequestDispatcher("/FashionStoreClient/").forward(request, response);
	}

}
