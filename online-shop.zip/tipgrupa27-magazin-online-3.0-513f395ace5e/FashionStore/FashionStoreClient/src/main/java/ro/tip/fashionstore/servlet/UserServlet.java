package ro.tip.fashionstore.servlet;

import java.io.IOException;
import java.net.URI;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import ro.tip.fashionstore.model.User;

@WebServlet(name = "userServlet", urlPatterns = { "/change-password" })
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClientConfig config;
	private Client client;
	private WebTarget service;
	private Response response;

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/FashionStoreWebServices/").build();
	}

	public UserServlet() {
		super();
		config = new ClientConfig();
		client = ClientBuilder.newClient(config);
		service = client.target(getBaseURI());
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (session.getAttribute("username") != null) {
			String newPassword = request.getParameter("new_pass");
			String confirmPassword = request.getParameter("confirm_pass");

			if (!newPassword.equals(confirmPassword)) {
				session.setAttribute("err-msg", "Passwords don't match!");
				response.sendRedirect("/FashionStoreClient/changePassword.jsp");
				return;
			}
			if (newPassword.length() < 5) {
				session.setAttribute("err-msg", "Password too weak! You need at least 5 characters");
				response.sendRedirect("/FashionStoreClient/changePassword.jsp");
				return;
			}
			long userId = Long.parseLong((String) session.getAttribute("userID"));
			this.response = service.path("api").path("users").path("user=" + userId).request()
					.accept(MediaType.APPLICATION_JSON).get(Response.class);
			User user = this.response.readEntity(User.class);
			user.setPassword(newPassword);

			// @PUT
			this.response = service.path("api").path("users").path("user=" + userId).request(MediaType.APPLICATION_JSON)
					.put(Entity.entity(user, MediaType.APPLICATION_JSON), Response.class);

			response.sendRedirect("/FashionStoreClient/");
		}
	}
}