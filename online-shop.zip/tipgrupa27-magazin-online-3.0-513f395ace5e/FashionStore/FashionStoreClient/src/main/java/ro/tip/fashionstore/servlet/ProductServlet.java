package ro.tip.fashionstore.servlet;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import ro.tip.fashionstore.model.Product;

@WebServlet(name = "productServlet", urlPatterns = { "/men-products", "", "/women-products", "/search" })
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClientConfig config;
	private Client client;
	private WebTarget service;
	private Response response;

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/FashionStoreWebServices/").build();
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductServlet() {
		super();
		config = new ClientConfig();
		client = ClientBuilder.newClient(config);
		service = client.target(getBaseURI());
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = request.getRequestURL().toString();
		boolean mainPage = false;

		if (url.contains("women")) {
			this.response = service.path("api").path("products").path("women").request()
					.accept(MediaType.APPLICATION_JSON).get(Response.class);
		} else if (url.contains("men")) {
			this.response = service.path("api").path("products").path("men").request()
					.accept(MediaType.APPLICATION_JSON).get(Response.class);
		} else if (url.contains("search")) {
			String search = request.getParameter("search");
			this.response = service.path("api").path("products").path("search").request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(search, MediaType.APPLICATION_JSON), Response.class);
		} else {
			mainPage = true;
			this.response = service.path("api").path("products").request().accept(MediaType.APPLICATION_JSON)
					.get(Response.class);
		}
		@SuppressWarnings("unchecked")
		List<LinkedHashMap<String, Object>> list = this.response.readEntity(List.class);

		List<Product> productList = new ArrayList<Product>();
		if (list == null)
			productList = null;
		else {
			for (LinkedHashMap<String, Object> linkedHashMap : list) {
				String name = (String) linkedHashMap.get("name");
				String description = (String) linkedHashMap.get("description");
				Double price = (Double) linkedHashMap.get("price");
				String size = (String) linkedHashMap.get("size");
				int stock = (Integer) linkedHashMap.get("stock");
				String productType = (String) linkedHashMap.get("type");
				String category = (String) linkedHashMap.get("category");
				String colour = (String) linkedHashMap.get("colour");
				String imagePath = (String) linkedHashMap.get("imagePath");
				char type = productType.charAt(0);
				Long productId = new Long((Integer) linkedHashMap.get("id"));
				Product product = new Product(name, description, price, size, stock, type, category, colour, imagePath);
				product.setId(productId);
				productList.add(product);
			}
		}

		request.setAttribute("productList", productList);
		if (!mainPage)
			request.getRequestDispatcher("products.jsp").forward(request, response);
		else
			request.getRequestDispatcher("index.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}