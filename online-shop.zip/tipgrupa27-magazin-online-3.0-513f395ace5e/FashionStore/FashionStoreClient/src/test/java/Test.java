import static org.junit.Assert.*;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;

public class Test {

	long getProductIdFromUrl(String url) {
		String[] result = url.split("/");
		int length = result.length;
		try {
			// 10 is the base of the product id which we want to parse
			return Long.parseLong(result[length - 1], 10);
		} catch (NumberFormatException e) {
			return -1L;
		}
	}

	private String getPathToWebContent() {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		URL url = classLoader.getResource("");
		File file;
		try {
			file = new File(url.toURI());
			String path = file.toPath().toString();
			return path.replace("target/test-classes", "WebContent");
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return null;
	}

	@org.junit.Test
	public void test() {
		System.out.println(getProductIdFromUrl("http://localhost:8080/FashionStoreClient/products/5"));
		System.out.println(getProductIdFromUrl("http://localhost:8080/FashionStoreClient/products/invalid"));
		System.out.println(getPathToWebContent());
		assertTrue(true);
	}

}
